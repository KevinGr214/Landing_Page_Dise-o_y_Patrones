# ParkEase – Landing Page

Landing page para la app de reserva de estacionamientos en Lima, Perú.

## Tecnologías
- Java 17
- Spring Boot 3.2
- HTML5 + CSS3 + JavaScript vanilla

## Requisitos
- Java 17+
- Maven 3.8+

## Cómo ejecutar

```bash
git clone https://github.com/TU-USUARIO/Landing_Page_Dise-o_y_Patrones.git
cd Landing_Page_Dise-o_y_Patrones
mvn spring-boot:run
```

Abre tu navegador en: http://localhost:8080

## Generar JAR ejecutable

```bash
mvn clean package
java -jar target/parkease-landing-1.0.0.jar
```

## Estructura

| Archivo | Descripción |
|---|---|
| ParkEaseApplication.java | Punto de entrada Spring Boot |
| ContactController.java | API REST para el formulario de contacto |
| static/index.html | Landing page completa (6 secciones) |
| static/css/styles.css | Todos los estilos |
| static/js/main.js | Navbar, formulario, animaciones |

## Secciones incluidas
- Hero con botones de descarga
- Cómo funciona (4 pasos)
- Características (6 funcionalidades)
- Para Conductores vs Para Gestores
- Testimonios con métricas
- Formulario de contacto + Footer
