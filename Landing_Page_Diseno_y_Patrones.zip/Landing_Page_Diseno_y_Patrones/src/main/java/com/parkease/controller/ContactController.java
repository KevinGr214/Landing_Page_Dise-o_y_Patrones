package com.parkease.controller;

import com.parkease.model.ContactRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class ContactController {

    @PostMapping("/contact")
    public ResponseEntity<Map<String, Object>> handleContact(
            @RequestBody ContactRequest request) {

        Map<String, Object> response = new HashMap<>();

        if (request.getNombre() == null || request.getNombre().isBlank()
                || request.getEmail() == null || request.getEmail().isBlank()
                || request.getMensaje() == null || request.getMensaje().isBlank()) {

            response.put("success", false);
            response.put("message", "Por favor completa todos los campos requeridos.");
            return ResponseEntity.badRequest().body(response);
        }

        // Aquí puedes integrar un servicio de email (JavaMailSender, SendGrid, etc.)
        System.out.printf("Nuevo contacto: %s <%s> [%s]%nMensaje: %s%n",
                request.getNombre(), request.getEmail(),
                request.getTipo(), request.getMensaje());

        response.put("success", true);
        response.put("message", "¡Mensaje enviado! Te contactaremos pronto.");
        return ResponseEntity.ok(response);
    }
}
